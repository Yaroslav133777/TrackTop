﻿using System.Collections.ObjectModel;
namespace TrackTop;

public class AppStateService
{
    public string Username { get; set; } = "Username";
    public string UsernameFirstLetter => $"{Username[0]}";
    public ObservableCollection<FolderModel> Tasks { get; set; } = new();
    public ObservableCollection<FolderModel> Folders { get; set; } = new();
    public ObservableCollection<TaskModel> TodayTasks { get; set; } = new();
    public ObservableCollection<TaskModel> PlannedTasks { get; set; } = new();
    public ObservableCollection<TaskModel> NotesTasks { get; set; } = new();
    public ObservableCollection<NoteModel> Notes { get; set; } = new();
    public AppStateService()
    {
        Folders.Add(new FolderModel("#EF5350") { FolderName = "Учёба" });
        Folders.Add(new FolderModel("#FF9800") { FolderName = "Работа" });
        Folders.Add(new FolderModel("#66CC66") { FolderName = "Дом" });
    }

    public void SortAllTasks()
    {
        SortCollection(TodayTasks);
        SortCollection(PlannedTasks);
        SortCollection(NotesTasks);
    }

    private void SortCollection(ObservableCollection<TaskModel> collection)
    {
        var sorted = collection.OrderBy(t => t.Date).ThenBy(t => t.Time ?? TimeOnly.MaxValue).ToList();
        for (int i = 0; i < sorted.Count; i++)
        {
            var currentIndex = collection.IndexOf(sorted[i]);
            if (currentIndex != i)
                collection.Move(currentIndex, i);
        }
    }
}