﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace TrackTop;

public class NoteModel : INotifyPropertyChanged
{
    private string _title = "";
    public string Title
    {
        get => _title;
        set { _title = value; OnPropertyChanged(); }
    }

    private string _description = "";
    public string Description
    {
        get => _description;
        set { _description = value; OnPropertyChanged(); }
    }

    private string _content = "";
    public string Content
    {
        get => _content;
        set { _content = value; OnPropertyChanged(); }
    }

    private FolderModel? _folder;
    public FolderModel? Folder
    {
        get => _folder;
        set { _folder = value; OnPropertyChanged(); OnPropertyChanged(nameof(FolderName)); OnPropertyChanged(nameof(HasFolder)); }
    }

    public string FolderName => Folder?.FolderName ?? "";
    public bool HasFolder => Folder != null;

    public DateTime CreatedDate { get; set; } = DateTime.Now;

    public NoteModel(string title, string description = "")
    {
        Title = title;
        Description = description;
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    protected void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}