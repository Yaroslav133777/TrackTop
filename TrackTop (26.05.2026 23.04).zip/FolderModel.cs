﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace TrackTop;

public class FolderModel : INotifyPropertyChanged
{
    private string _folderName = "default";
    public string FolderName
    {
        get => _folderName;
        set
        {
            _folderName = value;
            OnPropertyChanged();
        }
    }

    public ObservableCollection<TaskModel> Tasks { get; set; } = new();
    public ObservableCollection<NoteModel> Notes { get; set; } = new();
    public Color FolderColor { get; set; }

    public int TaskCount => Tasks.Count;

    public FolderModel(string color)
    {
        FolderColor = Color.FromArgb(color);
        Tasks.CollectionChanged += (s, e) => OnPropertyChanged(nameof(TaskCount));
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    public void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}