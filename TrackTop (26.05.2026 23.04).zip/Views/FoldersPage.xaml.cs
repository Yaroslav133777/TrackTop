﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrackTop.Views;
using CommunityToolkit.Maui;
using CommunityToolkit.Maui.Extensions;
namespace TrackTop;

public partial class FoldersPage : ContentPage
{
    private AppStateService _appState;

    public FoldersPage()
    {
        InitializeComponent();
        _appState = Application.Current!.Handler!.MauiContext!.Services.GetService<AppStateService>()!;
        BindingContext = _appState;

        UpdateEmptyState();
        _appState.Folders.CollectionChanged += OnFoldersChanged;
    }

    private void OnFoldersChanged(object? sender, NotifyCollectionChangedEventArgs e)
    {
        UpdateEmptyState();
    }

    private void UpdateEmptyState()
    {
        EmptyStateLayout.IsVisible = _appState.Folders.Count == 0;
    }

    private async void OnOpenPopupClicked(object sender, EventArgs e)
    {
        await this.ShowPopupAsync(new FolderCreator(), new PopupOptions
        {
            CanBeDismissedByTappingOutsideOfPopup = true,
            PageOverlayColor = Color.FromRgba(0, 0, 0, 120)
        });
    }

    private async void OnFolderTapped(object? sender, TappedEventArgs e)
    {
        if (sender is Grid grid && grid.BindingContext is FolderModel folder)
        {
            await this.ShowPopupAsync(new FolderViewPopup(folder), new PopupOptions
            {
                CanBeDismissedByTappingOutsideOfPopup = true,
                PageOverlayColor = Color.FromRgba(0, 0, 0, 120)
            });
        }
    }

    private async void OnDeleteFolderTapped(object? sender, TappedEventArgs e)
    {
        if (sender is Label label && label.BindingContext is FolderModel folder)
        {
            bool delete = await DisplayAlert(
                "Удалить папку",
                $"Вы уверены, что хотите удалить папку «{folder.FolderName}»?",
                "Удалить",
                "Отмена");

            if (delete)
            {
                foreach (var task in folder.Tasks)
                {
                    task.Folder = null;
                }
                _appState.Folders.Remove(folder);
            }
        }
    }
}