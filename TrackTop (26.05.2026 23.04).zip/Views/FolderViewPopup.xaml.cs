﻿using CommunityToolkit.Maui.Views;

namespace TrackTop.Views;

public partial class FolderViewPopup : Popup
{
    private TaskModel? _editingTask;
    private NoteModel? _editingNote;
    private AppStateService _appState;

    public FolderViewPopup(FolderModel folder)
    {
        InitializeComponent();
        BindingContext = folder;
        _appState = Application.Current!.Handler!.MauiContext!.Services.GetService<AppStateService>()!;
    }

    private void OnTaskCheckTapped(object? sender, TappedEventArgs e)
    {
        if (sender is Border border && border.BindingContext is TaskModel task)
            task.IsCompleted = !task.IsCompleted;
    }

    private void OnExpandTapped(object? sender, TappedEventArgs e)
    {
        if (sender is Label label && label.BindingContext is TaskModel task)
            task.IsExpanded = !task.IsExpanded;
    }

    private async void OnDeleteTaskTapped(object? sender, TappedEventArgs e)
    {
        if (sender is Label label && label.BindingContext is TaskModel task)
        {
            bool delete = await Application.Current!.Windows[0].Page!.DisplayAlert(
                "Удалить задачу", "Вы уверены?", "Удалить", "Отмена");

            if (delete)
            {
                _appState.TodayTasks.Remove(task);
                _appState.PlannedTasks.Remove(task);
                _appState.NotesTasks.Remove(task);

                if (BindingContext is FolderModel folder)
                    folder.Tasks.Remove(task);
            }
        }
    }

    private async void OnDeleteNoteTapped(object? sender, TappedEventArgs e)
    {
        if (sender is Label label && label.BindingContext is NoteModel note)
        {
            bool delete = await Application.Current!.Windows[0].Page!.DisplayAlert(
                "Удалить заметку", "Вы уверены?", "Удалить", "Отмена");

            if (delete)
            {
                _appState.Notes.Remove(note);
                if (BindingContext is FolderModel folder)
                    folder.Notes.Remove(note);
            }
        }
    }

    private void OnTitleTapped(object? sender, TappedEventArgs e)
    {
        if (sender is Label label)
        {
            if (label.BindingContext is TaskModel task)
                OpenTaskEditor(task);
            else if (label.BindingContext is NoteModel note)
                OpenNoteEditor(note);
        }
    }

    private void OnNoteTapped(object? sender, TappedEventArgs e)
    {
        if (sender is Label label && label.BindingContext is NoteModel note)
            OpenNoteEditor(note);
    }

    private void OpenTaskEditor(TaskModel task)
    {
        _editingTask = task;
        _editingNote = null;

        SheetTitle.Text = "Редактирование задачи";
        EditTitle.Text = task.Title;
        EditDescription.Text = task.Description;
        EditContent.Text = "";
        EditDate.Date = new DateTime(task.Date.Year, task.Date.Month, task.Date.Day);
        if (task.Time.HasValue)
            EditTime.Time = new TimeSpan(task.Time.Value.Hour, task.Time.Value.Minute, 0);
        EditRegular.IsToggled = task.IsRegular;
        EditNotification.IsToggled = task.HasNotification;

        ContentSection.IsVisible = false;
        DateTimeSection.IsVisible = true;
        RegularSection.IsVisible = true;
        NotificationSection.IsVisible = true;

        FillFolderPicker(task.Folder);

        OpenSheet();
    }

    private void OpenNoteEditor(NoteModel note)
    {
        _editingNote = note;
        _editingTask = null;

        SheetTitle.Text = "Редактирование заметки";
        EditTitle.Text = note.Title;
        EditDescription.Text = note.Description;
        EditContent.Text = note.Content;

        ContentSection.IsVisible = true;
        DateTimeSection.IsVisible = false;
        RegularSection.IsVisible = false;
        NotificationSection.IsVisible = false;

        FillFolderPicker(note.Folder);

        OpenSheet();
    }

    private void FillFolderPicker(FolderModel? currentFolder)
    {
        var folderList = new List<FolderModel> { new FolderModel("#CCCCCC") { FolderName = "Без папки" } };
        folderList.AddRange(_appState.Folders);
        EditFolderPicker.ItemsSource = folderList;

        if (currentFolder != null)
        {
            foreach (FolderModel f in folderList)
                if (f.FolderName == currentFolder.FolderName) { EditFolderPicker.SelectedItem = f; return; }
        }
        EditFolderPicker.SelectedIndex = 0;
    }

    private void OpenSheet()
    {
        Overlay.IsVisible = true;
        Overlay.InputTransparent = false;
        Overlay.FadeTo(0.5, 200);
        BottomSheet.TranslateTo(0, 0, 300, Easing.CubicOut);
    }

    private async void CloseBottomSheet(object? sender, EventArgs e)
    {
        await CloseSheet();
    }

    private async System.Threading.Tasks.Task CloseSheet()
    {
        await Overlay.FadeTo(0, 200);
        await BottomSheet.TranslateTo(0, 700, 300, Easing.CubicIn);
        Overlay.IsVisible = false;
        Overlay.InputTransparent = true;
        BottomSheet.TranslationY = 700;
    }

    private async void SaveFromSheet(object? sender, EventArgs e)
    {
        if (_editingTask != null)
        {
            _editingTask.Title = EditTitle.Text;
            _editingTask.Description = EditDescription.Text;
            _editingTask.Date = DateOnly.FromDateTime(EditDate.Date ?? DateTime.Today);
            _editingTask.Time = EditTime.Time.HasValue ? TimeOnly.FromTimeSpan(EditTime.Time.Value) : null;
            _editingTask.IsRegular = EditRegular.IsToggled;
            _editingTask.HasNotification = EditNotification.IsToggled;

            if (_editingTask.Folder != null)
            {
                _editingTask.Folder.Tasks.Remove(_editingTask);
                _editingTask.Folder.OnPropertyChanged(nameof(FolderModel.TaskCount));
            }

            if (EditFolderPicker.SelectedItem is FolderModel f && f.FolderName != "Без папки")
            {
                f.Tasks.Add(_editingTask);
                _editingTask.Folder = f;
                f.OnPropertyChanged(nameof(FolderModel.TaskCount));
            }
            else _editingTask.Folder = null;

            _appState.SortAllTasks();
        }
        else if (_editingNote != null)
        {
            _editingNote.Title = EditTitle.Text;
            _editingNote.Description = EditDescription.Text;
            _editingNote.Content = EditContent.Text;

            if (_editingNote.Folder != null)
                _editingNote.Folder.Notes.Remove(_editingNote);

            if (EditFolderPicker.SelectedItem is FolderModel f && f.FolderName != "Без папки")
            {
                f.Notes.Add(_editingNote);
                _editingNote.Folder = f;
            }
            else _editingNote.Folder = null;
        }

        await CloseSheet();
    }

    private async void DeleteFromSheet(object? sender, EventArgs e)
    {
        bool delete = await Application.Current!.Windows[0].Page!.DisplayAlert(
            "Удалить", "Вы уверены?", "Удалить", "Отмена");
        if (!delete) return;

        if (_editingTask != null)
        {
            _appState.TodayTasks.Remove(_editingTask);
            _appState.PlannedTasks.Remove(_editingTask);
            _appState.NotesTasks.Remove(_editingTask);
            foreach (var f in _appState.Folders) f.Tasks.Remove(_editingTask);
        }
        else if (_editingNote != null)
        {
            _appState.Notes.Remove(_editingNote);
            if (_editingNote.Folder != null)
                _editingNote.Folder.Notes.Remove(_editingNote);
        }

        await CloseSheet();
    }
}