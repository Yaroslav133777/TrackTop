﻿using CommunityToolkit.Maui;
using CommunityToolkit.Maui.Alerts;
using CommunityToolkit.Maui.Extensions;
using CommunityToolkit.Maui.Media;
using System.Globalization;
using TrackTop.Views;
namespace TrackTop;
public partial class MainPage : ContentPage
{
    private AppStateService _appState;

    public MainPage()
    {
        speechToText = Application.Current?.Handler?.MauiContext?.Services.GetService<ISpeechToText>() ?? SpeechToText.Default;
        _appState = Application.Current!.Handler!.MauiContext!.Services.GetService<AppStateService>()!;

        InitializeComponent();

        if (Application.Current?.RequestedTheme == AppTheme.Light)
            DarkModeButton.Source = "sunny.png";

        selectedButton = TodayButton;
        selectedButton.BackgroundColor = Color.FromRgba("#5B4CF0");

        BindingContext = _appState;
        TasksCollection.ItemsSource = _appState.TodayTasks;
        _appState.TodayTasks.CollectionChanged += (s, e) => UpdateEmptyState();
        _appState.PlannedTasks.CollectionChanged += (s, e) => UpdateEmptyState();
        _appState.NotesTasks.CollectionChanged += (s, e) => UpdateEmptyState();
        _appState.Notes.Add(new NoteModel("Тестовая заметка", "Описание теста"));
        RefreshTasksView();

        App.ThemeChanged += OnThemeChanged;

        UpdateEmptyState();
    }
    private Button selectedButton;
    private readonly ISpeechToText speechToText;
    private CancellationTokenSource? cancellationTokenSource;
    private bool manuallyStopped = false;
    private string RecognizedText { get; set; }
    public Color ThemeIconColor =>
        Application.Current?.RequestedTheme == AppTheme.Dark
            ? Colors.White 
            : Colors.Black;
    public Color ThemeTextColor =>
        Application.Current?.RequestedTheme == AppTheme.Dark
            ? Colors.White
            : Colors.Black;
    private async void Listen(object? sender, EventArgs args)
    {
        RecognizedText = string.Empty;
        manuallyStopped = false;
        speechToText.StateChanged -= OnSpeechStateChanged;
        speechToText.RecognitionResultCompleted -= OnRecognitionTextCompleted;
        speechToText.RecognitionResultUpdated -= OnRecognitionTextUpdated;
        cancellationTokenSource?.Cancel();
        cancellationTokenSource = new CancellationTokenSource();
        speechToText.StateChanged += OnSpeechStateChanged;
        speechToText.RecognitionResultCompleted += OnRecognitionTextCompleted;
        speechToText.RecognitionResultUpdated += OnRecognitionTextUpdated;
        try
        {
            var isGranted = await speechToText.RequestPermissions(cancellationTokenSource.Token);
            if (!isGranted)
            {
                await Toast.Make("Permission not granted").Show(CancellationToken.None);
                return;
            }
            await speechToText.StartListenAsync(new SpeechToTextOptions { Culture = CultureInfo.CurrentCulture, ShouldReportPartialResults = false}, cancellationTokenSource.Token);
            MicButton.BackgroundColor = Colors.Red;
            MicButton.Source = "stop_image.png";
            MicButton.Clicked -= Listen;
            MicButton.Clicked += StopListening;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Exception is: {ex.Message}");
        }
    }
    private async void StopListening(object? sender, EventArgs args)
    {
        manuallyStopped = true;
        await speechToText.StopListenAsync(CancellationToken.None);
        speechToText.StateChanged -= OnSpeechStateChanged;
        speechToText.RecognitionResultCompleted -= OnRecognitionTextCompleted;
        MicButton.Clicked += Listen;
        MicButton.Clicked -= StopListening;
        MicButton.SetAppThemeColor(BackgroundColorProperty, Color.FromArgb("#FF512BD4"), Color.FromArgb("#FFAC99EA"));
        MicButton.Source = "mic_image.png";
        
    }
    private async void OnRecognitionTextUpdated(object? sender, SpeechToTextRecognitionResultUpdatedEventArgs args)
    {
        await Toast.Make($"{args.RecognitionResult}").Show(CancellationToken.None);
    }
    private void OnRecognitionTextCompleted(object? sender, SpeechToTextRecognitionResultCompletedEventArgs args)
    {
        RecognizedText = args.RecognitionResult.Text;
    }
    private async void OnSpeechStateChanged(object? sender, SpeechToTextStateChangedEventArgs e)
    {
        if (e.State == SpeechToTextState.Silence || e.State == SpeechToTextState.Stopped)
        {
            MicButton.Clicked += Listen;
            MicButton.Clicked -= StopListening;
            MicButton.SetAppThemeColor(BackgroundColorProperty, Color.FromArgb("#FF512BD4"), Color.FromArgb("#FFAC99EA"));
            MicButton.Source = "mic_image.png";
            await Toast.Make($"Запись остановлена").Show(CancellationToken.None);
        }
    }
    private void OnAvatarClicked(object? sender, EventArgs e)
    {
        if (Parent is NavTabbedPage navPage)
        {
            navPage.CurrentPage = navPage.Children[2];
        }
    }
    private void ThemeSwitcher(object? sender, EventArgs e)
    {
        bool isDark = Application.Current!.RequestedTheme != AppTheme.Dark;
        App.SetTheme(isDark);
    }
    private void OnThemeChanged(bool isDark)
    {
        DarkModeButton.Source = isDark ? "dark_mode.png" : "sunny.png";

        var inactiveBg = isDark ? Color.FromRgba("#2B2B31") : Colors.White;
        if (selectedButton != TodayButton) TodayButton.BackgroundColor = inactiveBg;
        if (selectedButton != PlannedButton) PlannedButton.BackgroundColor = inactiveBg;
        if (selectedButton != NotesButton) NotesButton.BackgroundColor = inactiveBg;
    }
    private async void OnOpenPopupClicked(object sender, EventArgs e)
    {
        if (selectedButton == NotesButton)
        {
            await this.ShowPopupAsync(new NoteCreator(), new PopupOptions
            {
                CanBeDismissedByTappingOutsideOfPopup = true,
                PageOverlayColor = Color.FromRgba(0, 0, 0, 120)
            });
        }
        else
        {
            await this.ShowPopupAsync(new TaskCreator(), new PopupOptions
            {
                CanBeDismissedByTappingOutsideOfPopup = true,
                PageOverlayColor = Color.FromRgba(0, 0, 0, 120)
            });
        }
    }

    private void SelectButton(object? sender, EventArgs e)
    {
        if (sender is Button button)
        {
            if (selectedButton == button) return;

            var inactiveBg = App.Current!.RequestedTheme == AppTheme.Dark
                ? Color.FromRgba("#2B2B31")
                : Colors.White;
            selectedButton.BackgroundColor = inactiveBg;

            selectedButton = button;
            selectedButton.BackgroundColor = Color.FromRgba("#5B4CF0");

            RefreshTasksView();
        }
    }

    public void RefreshTasksView()
    {
        if (selectedButton == TodayButton)
            TasksCollection.ItemsSource = _appState.TodayTasks.OrderBy(t => t.Date).ThenBy(t => t.Time ?? TimeOnly.MaxValue).ToList();
        else if (selectedButton == PlannedButton)
            TasksCollection.ItemsSource = _appState.PlannedTasks.OrderBy(t => t.Date).ThenBy(t => t.Time ?? TimeOnly.MaxValue).ToList();
        else if (selectedButton == NotesButton)
            TasksCollection.ItemsSource = _appState.Notes.ToList();

        UpdateEmptyState();
        TasksCollection.IsVisible = TasksCollection.ItemsSource is System.Collections.IList list && list.Count > 0;
    }

    private void UpdateEmptyState()
    {
        int count = 0;
        if (TasksCollection.ItemsSource is System.Collections.IList list)
            count = list.Count;

        EmptyStateLayout.IsVisible = count == 0;
        TasksCollection.IsVisible = count > 0;
    }

    private void OnTaskCheckTapped(object? sender, TappedEventArgs e)
    {
        if (sender is Border border && border.BindingContext is TaskModel task)
        {
            task.IsCompleted = !task.IsCompleted;
        }
    }

    private async void OnDeleteTaskTapped(object? sender, TappedEventArgs e)
    {
        if (sender is Label label && label.BindingContext is TaskModel task)
        {
            bool delete = await DisplayAlert(
                "Удалить задачу",
                "Вы уверены, что хотите удалить эту задачу?",
                "Удалить",
                "Отмена");

            if (delete)
            {
                _appState.TodayTasks.Remove(task);
                _appState.PlannedTasks.Remove(task);
                _appState.NotesTasks.Remove(task);

                foreach (var folder in _appState.Folders)
                {
                    folder.Tasks.Remove(task);
                }

                UpdateEmptyState();
            }
        }
    }

    private void OnExpandTapped(object? sender, TappedEventArgs e)
    {
        if (sender is Label label && label.BindingContext is TaskModel task)
        {
            task.IsExpanded = !task.IsExpanded;
        }
    }

    private TaskModel? _editingTask;

    private NoteModel? _editingNote;

    private void OnTitleTapped(object? sender, TappedEventArgs e)
    {
        if (sender is Label label)
        {
            if (label.BindingContext is TaskModel task)
                OpenTaskEditor(task);
            else if (label.BindingContext is NoteModel note)
                OpenNoteEditor(note);
        }
    }

    private void OpenTaskEditor(TaskModel task)
    {
        _editingTask = task;
        _editingNote = null;

        SheetTitle.Text = "Редактирование задачи";
        EditTitle.Text = task.Title;
        EditDescription.Text = task.Description;
        EditContent.Text = "";
        EditDate.Date = new DateTime(task.Date.Year, task.Date.Month, task.Date.Day);
        if (task.Time.HasValue)
            EditTime.Time = new TimeSpan(task.Time.Value.Hour, task.Time.Value.Minute, 0);
        EditRegular.IsToggled = task.IsRegular;
        EditNotification.IsToggled = task.HasNotification;

        ContentSection.IsVisible = false;
        DateTimeSection.IsVisible = true;
        RegularSection.IsVisible = true;
        NotificationSection.IsVisible = true;

        var folderList = new List<FolderModel> { new FolderModel("#CCCCCC") { FolderName = "Без папки" } };
        folderList.AddRange(_appState.Folders);
        EditFolderPicker.ItemsSource = folderList;

        if (task.Folder != null)
        {
            foreach (FolderModel f in folderList)
                if (f.FolderName == task.Folder.FolderName) { EditFolderPicker.SelectedItem = f; break; }
        }
        else EditFolderPicker.SelectedIndex = 0;

        OpenSheet();
    }

    private void OpenNoteEditor(NoteModel note)
    {
        _editingNote = note;
        _editingTask = null;

        SheetTitle.Text = "Редактирование заметки";
        EditTitle.Text = note.Title;
        EditDescription.Text = note.Description;
        EditContent.Text = note.Content;

        ContentSection.IsVisible = true;
        DateTimeSection.IsVisible = false;
        RegularSection.IsVisible = false;
        NotificationSection.IsVisible = false;

        var folderList = new List<FolderModel> { new FolderModel("#CCCCCC") { FolderName = "Без папки" } };
        folderList.AddRange(_appState.Folders);
        EditFolderPicker.ItemsSource = folderList;

        if (note.Folder != null)
        {
            foreach (FolderModel f in folderList)
                if (f.FolderName == note.Folder.FolderName) { EditFolderPicker.SelectedItem = f; break; }
        }
        else EditFolderPicker.SelectedIndex = 0;

        OpenSheet();
    }

    private void OpenSheet()
    {
        Overlay.IsVisible = true;
        Overlay.InputTransparent = false;
        Overlay.FadeTo(0.5, 200);
        BottomSheet.TranslateTo(0, 0, 300, Easing.CubicOut);
    }

    private async void CloseBottomSheet(object? sender, EventArgs e)
    {
        await CloseSheet();
    }

    private async void SaveFromSheet(object? sender, EventArgs e)
    {
        if (_editingTask != null)
        {
            _editingTask.Title = EditTitle.Text;
            _editingTask.Description = EditDescription.Text;
            _editingTask.Date = DateOnly.FromDateTime(EditDate.Date ?? DateTime.Today);
            _editingTask.Time = EditTime.Time.HasValue ? TimeOnly.FromTimeSpan(EditTime.Time.Value) : null;
            _editingTask.IsRegular = EditRegular.IsToggled;
            _editingTask.HasNotification = EditNotification.IsToggled;

            if (_editingTask.Folder != null)
            {
                _editingTask.Folder.Tasks.Remove(_editingTask);
                _editingTask.Folder.OnPropertyChanged(nameof(FolderModel.TaskCount));
            }

            if (EditFolderPicker.SelectedItem is FolderModel f && f.FolderName != "Без папки")
            {
                f.Tasks.Add(_editingTask);
                _editingTask.Folder = f;
                f.OnPropertyChanged(nameof(FolderModel.TaskCount));
            }
            else _editingTask.Folder = null;

            _appState.SortAllTasks();
        }
        else if (_editingNote != null)
        {
            _editingNote.Title = EditTitle.Text;
            _editingNote.Description = EditDescription.Text;
            _editingNote.Content = EditContent.Text;

            if (_editingNote.Folder != null)
                _editingNote.Folder.Notes.Remove(_editingNote);

            if (EditFolderPicker.SelectedItem is FolderModel f && f.FolderName != "Без папки")
            {
                f.Notes.Add(_editingNote);
                _editingNote.Folder = f;
            }
            else
            {
                _editingNote.Folder = null;
            }
        }

        RefreshTasksView();
        await CloseSheet();
    }

    private async System.Threading.Tasks.Task CloseSheet()
    {
        await Overlay.FadeTo(0, 200);
        await BottomSheet.TranslateTo(0, 600, 300, Easing.CubicIn);
        Overlay.IsVisible = false;
        Overlay.InputTransparent = true;
        BottomSheet.TranslationY = 600;
    }

    private async void DeleteFromSheet(object? sender, EventArgs e)
    {
        bool delete = await DisplayAlert("Удалить", "Вы уверены?", "Удалить", "Отмена");
        if (!delete) return;

        if (_editingTask != null)
        {
            _appState.TodayTasks.Remove(_editingTask);
            _appState.PlannedTasks.Remove(_editingTask);
            _appState.NotesTasks.Remove(_editingTask);
            foreach (var f in _appState.Folders) f.Tasks.Remove(_editingTask);
        }
        else if (_editingNote != null)
        {
            _appState.Notes.Remove(_editingNote);
        }

        RefreshTasksView();
        await CloseSheet();
    }
}