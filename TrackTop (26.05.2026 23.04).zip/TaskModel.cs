﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace TrackTop;

public class TaskModel : INotifyPropertyChanged
{
    private string? _title;
    public string? Title
    {
        get => _title;
        set
        {
            _title = value;
            OnPropertyChanged();
        }
    }

    private bool _isExpanded;
    public bool IsExpanded
    {
        get => _isExpanded;
        set
        {
            _isExpanded = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(ExpandIcon));
        }
    }

    private FolderModel? _folder;
    public FolderModel? Folder
    {
        get => _folder;
        set
        {
            _folder = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(FolderName));
        }
    }

    private bool _isRegular;
    public bool IsRegular
    {
        get => _isRegular;
        set
        {
            _isRegular = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(HasRegular));
        }
    }

    public bool HasRegular => IsRegular;

    private bool _hasNotification;
    public bool HasNotification
    {
        get => _hasNotification;
        set
        {
            _hasNotification = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(NotificationIcon));
        }
    }

    public string NotificationIcon => HasNotification ? "🔔" : "🔕";

    public string FolderName => Folder?.FolderName ?? "";
    public bool HasFolder => Folder != null;

    public string ExpandIcon => IsExpanded ? "▲" : "▼";

    private string? _description;
    public string? Description
    {
        get => _description;
        set
        {
            _description = value;
            OnPropertyChanged();
        }
    }

    private DateOnly _date;
    public DateOnly Date
    {
        get => _date;
        set
        {
            _date = value;
            OnPropertyChanged();
        }
    }

    private TimeOnly? _time;
    public TimeOnly? Time
    {
        get => _time;
        set
        {
            _time = value;
            OnPropertyChanged();
        }
    }

    public bool Notify { get; set; }

    private bool _isCompleted;
    public bool IsCompleted
    {
        get => _isCompleted;
        set
        {
            _isCompleted = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(TextDecoration));
            OnPropertyChanged(nameof(Opacity));
        }
    }

    public TextDecorations TextDecoration => IsCompleted ? TextDecorations.Strikethrough : TextDecorations.None;
    public double Opacity => IsCompleted ? 0.5 : 1.0;

    public TaskModel(string? title, string? description, DateOnly date, TimeOnly? time, bool notify)
    {
        Title = title;
        _description = description;
        _date = date;
        _time = time;
        _hasNotification = notify;
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}