﻿using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace TrackTop;

public class NoteModel : INotifyPropertyChanged
{
    private string _title = "";
    public string Title
    {
        get => _title;
        set { _title = value; OnPropertyChanged(); }
    }

    private string _description = "";
    public string Description
    {
        get => _description;
        set { _description = value; OnPropertyChanged(); }
    }

    private string _content = "";
    public string Content
    {
        get => _content;
        set { _content = value; OnPropertyChanged(); }
    }

    public string? FolderName_Serialized { get; set; }
    public string? FolderColor_Serialized { get; set; }

    [JsonIgnore]
    public FolderModel? Folder { get; set; }

    [JsonIgnore]
    public string FolderName => Folder?.FolderName ?? "";

    [JsonIgnore]
    public bool HasFolder => Folder != null;

    public DateTime CreatedDate { get; set; } = DateTime.Now;

    public NoteModel() { }

    public NoteModel(string title, string description = "")
    {
        _title = title;
        _description = description;
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    protected void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}