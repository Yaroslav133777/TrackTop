﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Maui.Controls;

namespace TrackTop;

public partial class App : Application
{
    public App()
    {
        InitializeComponent();
        UserAppTheme = AppTheme.Unspecified;

        var appState = Handler?.MauiContext?.Services.GetService<AppStateService>();
        if (appState != null)
            DataService.Load(appState);
    }
    protected override Window CreateWindow(IActivationState? activationState)
    {
        var window = new Window(new NavTabbedPage());

#if WINDOWS
    window.MinimumWidth = 850;  
    window.MinimumHeight = 620;    
    window.Width = 1100;
    window.Height = 720;
#endif

        var appState = Current!.Handler!.MauiContext!.Services.GetService<AppStateService>();
        DataService.Load(appState!);

        return window;
    }

    public static event Action<bool>? ThemeChanged;
    public static void SetTheme(bool isDark)
    {
        Application.Current!.UserAppTheme = isDark ? AppTheme.Dark : AppTheme.Light;
        ThemeChanged?.Invoke(isDark);
    }
}