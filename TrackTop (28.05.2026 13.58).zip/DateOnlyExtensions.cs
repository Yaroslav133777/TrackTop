﻿namespace System;

public static class DateOnlyExtensions
{
    public static DateTime ToDateTime(this DateOnly dateOnly, TimeOnly time)
    {
        return dateOnly.ToDateTime(time);
    }
}