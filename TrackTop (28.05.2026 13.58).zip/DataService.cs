﻿using System.Text.Json;

namespace TrackTop;

public static class DataService
{
    private static readonly string FilePath = Path.Combine(FileSystem.AppDataDirectory, "tracktop_data.json");

    public static void Save(AppStateService appState)
    {
        // Заполняем сериализуемые поля перед сохранением
        foreach (var task in appState.TodayTasks)
            FillSerializedFolder(task);
        foreach (var task in appState.PlannedTasks)
            FillSerializedFolder(task);
        foreach (var task in appState.NotesTasks)
            FillSerializedFolder(task);
        foreach (var note in appState.Notes)
            FillSerializedFolder(note);

        var data = new SaveData
        {
            Folders = appState.Folders.ToList(),
            TodayTasks = appState.TodayTasks.ToList(),
            PlannedTasks = appState.PlannedTasks.ToList(),
            NotesTasks = appState.NotesTasks.ToList(),
            Notes = appState.Notes.ToList()
        };

        var json = JsonSerializer.Serialize(data, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(FilePath, json);
    }

    private static void FillSerializedFolder(TaskModel task)
    {
        task.FolderName_Serialized = task.Folder?.FolderName;
        task.FolderColor_Serialized = task.Folder?.ColorHex;
    }

    private static void FillSerializedFolder(NoteModel note)
    {
        note.FolderName_Serialized = note.Folder?.FolderName;
        note.FolderColor_Serialized = note.Folder?.ColorHex;
    }

    public static void Load(AppStateService appState)
    {
        if (!File.Exists(FilePath)) return;

        var json = File.ReadAllText(FilePath);
        var data = JsonSerializer.Deserialize<SaveData>(json);
        if (data == null) return;

        foreach (var folder in data.Folders)
            appState.Folders.Add(folder);

        foreach (var task in data.TodayTasks)
        {
            RestoreTaskFolder(task, data.Folders);
            appState.TodayTasks.Add(task);
        }

        foreach (var task in data.PlannedTasks)
        {
            RestoreTaskFolder(task, data.Folders);
            appState.PlannedTasks.Add(task);
        }

        foreach (var task in data.NotesTasks)
        {
            RestoreTaskFolder(task, data.Folders);
            appState.NotesTasks.Add(task);
        }

        foreach (var note in data.Notes)
        {
            RestoreNoteFolder(note, data.Folders);
            appState.Notes.Add(note);
        }
    }

    private static void RestoreTaskFolder(TaskModel task, List<FolderModel> folders)
    {
        if (!string.IsNullOrEmpty(task.FolderName_Serialized))
        {
            var match = folders.FirstOrDefault(f =>
                f.FolderName == task.FolderName_Serialized && f.ColorHex == task.FolderColor_Serialized);
            if (match != null)
            {
                task.Folder = match;
                if (!match.Tasks.Contains(task))
                    match.Tasks.Add(task);
            }
        }
    }

    private static void RestoreNoteFolder(NoteModel note, List<FolderModel> folders)
    {
        if (!string.IsNullOrEmpty(note.FolderName_Serialized))
        {
            var match = folders.FirstOrDefault(f =>
                f.FolderName == note.FolderName_Serialized && f.ColorHex == note.FolderColor_Serialized);
            if (match != null)
            {
                note.Folder = match;
                if (!match.Notes.Contains(note))
                    match.Notes.Add(note);
            }
        }
    }

    private static void RestoreFolderReference(TaskModel task, List<FolderModel> folders)
    {
        if (task.Folder != null)
        {
            var match = folders.FirstOrDefault(f =>
                f.FolderName == task.Folder.FolderName && f.ColorHex == task.Folder.ColorHex);
            if (match != null)
            {
                task.Folder = match;
                if (!match.Tasks.Contains(task))
                    match.Tasks.Add(task);
            }
        }
    }

    private static void RestoreFolderReference(NoteModel note, List<FolderModel> folders)
    {
        if (note.Folder != null)
        {
            var match = folders.FirstOrDefault(f =>
                f.FolderName == note.Folder.FolderName && f.ColorHex == note.Folder.ColorHex);
            if (match != null)
            {
                note.Folder = match;
                if (!match.Notes.Contains(note))
                    match.Notes.Add(note);
            }
        }
    }
}

public class SaveData
{
    public List<FolderModel> Folders { get; set; } = new();
    public List<TaskModel> TodayTasks { get; set; } = new();
    public List<TaskModel> PlannedTasks { get; set; } = new();
    public List<TaskModel> NotesTasks { get; set; } = new();
    public List<NoteModel> Notes { get; set; } = new();
}