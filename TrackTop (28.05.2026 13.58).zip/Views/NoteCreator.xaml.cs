using CommunityToolkit.Maui.Storage;
using CommunityToolkit.Maui.Views;

namespace TrackTop.Views;

public partial class NoteCreator : Popup
{
    private AppStateService _appState;

    public NoteCreator()
    {
        InitializeComponent();
        _appState = Application.Current!.Handler!.MauiContext!.Services.GetService<AppStateService>()!;

        var folderList = new List<FolderModel> { new FolderModel("#CCCCCC") { FolderName = "Без папки" } };
        folderList.AddRange(_appState.Folders);
        FolderPicker.ItemsSource = folderList;
        FolderPicker.SelectedIndex = 0;
    }

    private async void ClosePage(object? sender, EventArgs e)
    {
        await CloseAsync();
    }

    private async void CreateNote(object? sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(TitleEntry.Text))
        {
            await Application.Current!.Windows[0].Page!.DisplayAlert("Ошибка", "Введите название заметки!", "OK");
            return;
        }

        var note = new NoteModel(TitleEntry.Text.Trim(), DescriptionEditor.Text?.Trim() ?? "");

        if (FolderPicker.SelectedItem is FolderModel folder && folder.FolderName != "Без папки")
        {
            note.Folder = folder;
            if (note.Folder != null)
            {
                note.Folder.Notes.Add(note);
            }
        }

        _appState.Notes.Add(note);

        var mainPage = Application.Current?.Windows[0].Page;
        if (mainPage is NavTabbedPage nav)
        {
            foreach (var child in nav.Children)
            {
                if (child is MainPage mp)
                {
                    mp.RefreshTasksView();
                    break;
                }
            }
        }

        await CloseAsync();
    }
}