﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrackTop;

public partial class SettingsPage : ContentPage
{
    private bool _ignoreSwitchEvent;

    public SettingsPage()
    {
        InitializeComponent();

        bool isDark = Application.Current!.RequestedTheme == AppTheme.Dark;
        ThemeSwitch.IsToggled = isDark;
        ThemeText.Text = isDark ? "Тёмная тема" : "Светлая тема";
        ThemeTextImage.Source = isDark ? "dark_mode.png" : "sunny.png";

        App.ThemeChanged += OnThemeChanged;
    }

    private void ThemeSwitcher(object? sender, ToggledEventArgs e)
    {
        if (_ignoreSwitchEvent) return;
        App.SetTheme(e.Value);
    }

    private void OnThemeChanged(bool isDark)
    {
        _ignoreSwitchEvent = true;
        ThemeSwitch.IsToggled = isDark;
        _ignoreSwitchEvent = false;

        ThemeText.Text = isDark ? "Тёмная тема" : "Светлая тема";
        ThemeTextImage.Source = isDark ? "dark_mode.png" : "sunny.png";
    }
}