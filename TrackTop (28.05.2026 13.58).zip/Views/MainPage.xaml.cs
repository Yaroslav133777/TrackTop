﻿using CommunityToolkit.Maui;
using CommunityToolkit.Maui.Alerts;
using CommunityToolkit.Maui.Extensions;
using CommunityToolkit.Maui.Media;
using System.Globalization;
using TrackTop.Views;

namespace TrackTop;

public partial class MainPage : ContentPage
{
    private AppStateService _appState;

    public MainPage()
    {
        speechToText = Application.Current?.Handler?.MauiContext?.Services.GetService<ISpeechToText>() ?? SpeechToText.Default;
        _appState = Application.Current!.Handler!.MauiContext!.Services.GetService<AppStateService>()!;

        InitializeComponent();

        if (Application.Current?.RequestedTheme == AppTheme.Light)
            DarkModeButton.Source = "sunny.png";

        selectedButton = TodayButton;
        selectedButton.BackgroundColor = Color.FromRgba("#5B4CF0");

        BindingContext = _appState;
        TasksCollection.ItemsSource = _appState.TodayTasks;
        _appState.TodayTasks.CollectionChanged += (s, e) => UpdateEmptyState();
        _appState.PlannedTasks.CollectionChanged += (s, e) => UpdateEmptyState();
        _appState.NotesTasks.CollectionChanged += (s, e) => UpdateEmptyState();
        RefreshTasksView();

        App.ThemeChanged += OnThemeChanged;
        UpdateEmptyState();
    }

    private Button selectedButton;
    private readonly ISpeechToText speechToText;
    private CancellationTokenSource? cancellationTokenSource;
    private string RecognizedText { get; set; }

    public Color ThemeIconColor =>
        Application.Current?.RequestedTheme == AppTheme.Dark ? Colors.White : Colors.Black;

    public Color ThemeTextColor =>
        Application.Current?.RequestedTheme == AppTheme.Dark ? Colors.White : Colors.Black;

    private async void Listen(object? sender, EventArgs args)
    {
        RecognizedText = string.Empty;
        speechToText.StateChanged -= OnSpeechStateChanged;
        speechToText.RecognitionResultCompleted -= OnRecognitionTextCompleted;
        speechToText.RecognitionResultUpdated -= OnRecognitionTextUpdated;
        cancellationTokenSource?.Cancel();
        cancellationTokenSource = new CancellationTokenSource();
        speechToText.StateChanged += OnSpeechStateChanged;
        speechToText.RecognitionResultCompleted += OnRecognitionTextCompleted;
        speechToText.RecognitionResultUpdated += OnRecognitionTextUpdated;
        try
        {
            var isGranted = await speechToText.RequestPermissions(cancellationTokenSource.Token);
            if (!isGranted)
            {
                await Toast.Make("Permission not granted").Show(CancellationToken.None);
                return;
            }
            await speechToText.StartListenAsync(new SpeechToTextOptions { Culture = CultureInfo.CurrentCulture, ShouldReportPartialResults = false }, cancellationTokenSource.Token);
            MicButton.BackgroundColor = Colors.Red;
            MicButton.Source = "stop_image.png";
            MicButton.Clicked -= Listen;
            MicButton.Clicked += StopListening;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Exception is: {ex.Message}");
        }
    }

    private async void StopListening(object? sender, EventArgs args)
    {
        await speechToText.StopListenAsync(CancellationToken.None);
        speechToText.StateChanged -= OnSpeechStateChanged;
        speechToText.RecognitionResultCompleted -= OnRecognitionTextCompleted;
        MicButton.Clicked += Listen;
        MicButton.Clicked -= StopListening;
        MicButton.SetAppThemeColor(BackgroundColorProperty, Color.FromArgb("#FF512BD4"), Color.FromArgb("#FFAC99EA"));
        MicButton.Source = "mic_image.png";
    }

    private async void OnRecognitionTextUpdated(object? sender, SpeechToTextRecognitionResultUpdatedEventArgs args)
    {
        await Toast.Make($"{args.RecognitionResult}").Show(CancellationToken.None);
    }

    private void OnRecognitionTextCompleted(object? sender, SpeechToTextRecognitionResultCompletedEventArgs args)
    {
        RecognizedText = args.RecognitionResult.Text;
    }

    private async void OnSpeechStateChanged(object? sender, SpeechToTextStateChangedEventArgs e)
    {
        if (e.State == SpeechToTextState.Silence || e.State == SpeechToTextState.Stopped)
        {
            MicButton.Clicked += Listen;
            MicButton.Clicked -= StopListening;
            MicButton.SetAppThemeColor(BackgroundColorProperty, Color.FromArgb("#FF512BD4"), Color.FromArgb("#FFAC99EA"));
            MicButton.Source = "mic_image.png";
            await Toast.Make($"Запись остановлена").Show(CancellationToken.None);
        }
    }

    private void OnAvatarClicked(object? sender, EventArgs e)
    {
        if (Parent is NavTabbedPage navPage)
            navPage.CurrentPage = navPage.Children[2];
    }

    private void ThemeSwitcher(object? sender, EventArgs e)
    {
        bool isDark = Application.Current!.RequestedTheme != AppTheme.Dark;
        App.SetTheme(isDark);
    }

    private void OnThemeChanged(bool isDark)
    {
        DarkModeButton.Source = isDark ? "dark_mode.png" : "sunny.png";
        var inactiveBg = isDark ? Color.FromRgba("#2B2B31") : Colors.White;
        if (selectedButton != TodayButton) TodayButton.BackgroundColor = inactiveBg;
        if (selectedButton != PlannedButton) PlannedButton.BackgroundColor = inactiveBg;
        if (selectedButton != NotesButton) NotesButton.BackgroundColor = inactiveBg;
    }

    private async void OnOpenPopupClicked(object sender, EventArgs e)
    {
        if (selectedButton == NotesButton)
        {
            await this.ShowPopupAsync(new NoteCreator(), new PopupOptions
            {
                CanBeDismissedByTappingOutsideOfPopup = true,
                PageOverlayColor = Color.FromRgba(0, 0, 0, 120)
            });
        }
        else
        {
            await this.ShowPopupAsync(new TaskCreator(), new PopupOptions
            {
                CanBeDismissedByTappingOutsideOfPopup = true,
                PageOverlayColor = Color.FromRgba(0, 0, 0, 120)
            });
        }
    }

    private void SelectButton(object? sender, EventArgs e)
    {
        if (sender is Button button)
        {
            if (selectedButton == button) return;
            var inactiveBg = App.Current!.RequestedTheme == AppTheme.Dark ? Color.FromRgba("#2B2B31") : Colors.White;
            selectedButton.BackgroundColor = inactiveBg;
            selectedButton = button;
            selectedButton.BackgroundColor = Color.FromRgba("#5B4CF0");
            RefreshTasksView();
        }
    }

    public void RefreshTasksView()
    {
        if (selectedButton == TodayButton)
            TasksCollection.ItemsSource = _appState.TodayTasks.OrderBy(t => t.Date).ThenBy(t => t.Time ?? TimeOnly.MaxValue).ToList();
        else if (selectedButton == PlannedButton)
            TasksCollection.ItemsSource = _appState.PlannedTasks.OrderBy(t => t.Date).ThenBy(t => t.Time ?? TimeOnly.MaxValue).ToList();
        else if (selectedButton == NotesButton)
            TasksCollection.ItemsSource = _appState.Notes.ToList();

        UpdateEmptyState();
        TasksCollection.IsVisible = TasksCollection.ItemsSource is System.Collections.IList list && list.Count > 0;
    }

    private void UpdateEmptyState()
    {
        int count = 0;
        if (TasksCollection.ItemsSource is System.Collections.IList list)
            count = list.Count;
        EmptyStateLayout.IsVisible = count == 0;
        TasksCollection.IsVisible = count > 0;
    }

    private void OnTaskCheckTapped(object? sender, TappedEventArgs e)
    {
        if (sender is Border border && border.BindingContext is TaskModel task)
            task.IsCompleted = !task.IsCompleted;
    }

    private async void OnDeleteTapped(object? sender, TappedEventArgs e)
    {
        if (sender is Label label)
        {
            if (label.BindingContext is TaskModel task)
            {
                bool delete = await DisplayAlert("Удалить задачу", "Вы уверены?", "Удалить", "Отмена");
                if (delete)
                {
                    _appState.TodayTasks.Remove(task);
                    _appState.PlannedTasks.Remove(task);
                    _appState.NotesTasks.Remove(task);
                    foreach (var folder in _appState.Folders)
                        folder.Tasks.Remove(task);
                    RefreshTasksView();
                }
            }
            else if (label.BindingContext is NoteModel note)
            {
                bool delete = await DisplayAlert("Удалить заметку", "Вы уверены?", "Удалить", "Отмена");
                if (delete)
                {
                    _appState.Notes.Remove(note);
                    if (note.Folder != null)
                        note.Folder.Notes.Remove(note);
                    RefreshTasksView();
                }
            }
        }
    }

    private void OnExpandTapped(object? sender, TappedEventArgs e)
    {
        if (sender is Label label && label.BindingContext is TaskModel task)
            task.IsExpanded = !task.IsExpanded;
    }

    private async void OnTitleTapped(object? sender, TappedEventArgs e)
    {
        if (sender is Label label)
        {
            if (label.BindingContext is TaskModel task)
            {
                await this.ShowPopupAsync(new TaskEditorPopup(task), new PopupOptions
                {
                    CanBeDismissedByTappingOutsideOfPopup = false,
                    PageOverlayColor = Color.FromRgba(0, 0, 0, 120)
                });
            }
            else if (label.BindingContext is NoteModel note)
            {
                await this.ShowPopupAsync(new TaskEditorPopup(note), new PopupOptions
                {
                    CanBeDismissedByTappingOutsideOfPopup = false,
                    PageOverlayColor = Color.FromRgba(0, 0, 0, 120)
                });
            }
        }
    }
}