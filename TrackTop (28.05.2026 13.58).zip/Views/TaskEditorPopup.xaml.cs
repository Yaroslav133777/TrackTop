using CommunityToolkit.Maui.Views;

namespace TrackTop.Views;

public partial class TaskEditorPopup : Popup
{
    private AppStateService _appState;
    private TaskModel? _task;
    private NoteModel? _note;

    public TaskEditorPopup(TaskModel task)
    {
        InitializeComponent();
        _appState = Application.Current!.Handler!.MauiContext!.Services.GetService<AppStateService>()!;
        _task = task;

        SheetTitle.Text = "Редактирование задачи";
        EditTitle.Text = task.Title;
        EditDescription.Text = task.Description;
        EditDate.Date = new DateTime(task.Date.Year, task.Date.Month, task.Date.Day);
        if (task.Time.HasValue)
            EditTime.Time = new TimeSpan(task.Time.Value.Hour, task.Time.Value.Minute, 0);
        EditRegular.IsToggled = task.IsRegular;
        EditNotification.IsToggled = task.HasNotification;

        ContentSection.IsVisible = false;
        DateTimeSection.IsVisible = true;
        RegularSection.IsVisible = true;
        NotificationSection.IsVisible = true;

        FillFolderPicker(task.Folder);
    }

    public TaskEditorPopup(NoteModel note)
    {
        InitializeComponent();
        _appState = Application.Current!.Handler!.MauiContext!.Services.GetService<AppStateService>()!;
        _note = note;

        SheetTitle.Text = "Редактирование заметки";
        EditTitle.Text = note.Title;
        EditDescription.Text = note.Description;
        EditContent.Text = note.Content;

        ContentSection.IsVisible = true;
        DateTimeSection.IsVisible = false;
        RegularSection.IsVisible = false;
        NotificationSection.IsVisible = false;

        FillFolderPicker(note.Folder);
    }

    private void FillFolderPicker(FolderModel? currentFolder)
    {
        var folderList = new List<FolderModel> { new FolderModel("#CCCCCC") { FolderName = "Без папки" } };
        folderList.AddRange(_appState.Folders);
        EditFolderPicker.ItemsSource = folderList;

        if (currentFolder != null)
        {
            foreach (FolderModel f in folderList)
                if (f.FolderName == currentFolder.FolderName) { EditFolderPicker.SelectedItem = f; return; }
        }
        EditFolderPicker.SelectedIndex = 0;
    }

    private async void SaveClicked(object? sender, EventArgs e)
    {
        if (_task != null)
        {
            _task.Title = EditTitle.Text;
            _task.Description = EditDescription.Text;
            _task.Date = DateOnly.FromDateTime(EditDate.Date ?? DateTime.Today);
            _task.Time = EditTime.Time.HasValue ? TimeOnly.FromTimeSpan(EditTime.Time.Value) : null;
            _task.IsRegular = EditRegular.IsToggled;
            _task.HasNotification = EditNotification.IsToggled;

            if (_task.Folder != null)
            {
                _task.Folder.Tasks.Remove(_task);
                _task.Folder.OnPropertyChanged(nameof(FolderModel.TaskCount));
            }

            if (EditFolderPicker.SelectedItem is FolderModel f && f.FolderName != "Без папки")
            {
                f.Tasks.Add(_task);
                _task.Folder = f;
                f.OnPropertyChanged(nameof(FolderModel.TaskCount));
            }
            else _task.Folder = null;

            _appState.SortAllTasks();
        }
        else if (_note != null)
        {
            _note.Title = EditTitle.Text;
            _note.Description = EditDescription.Text;
            _note.Content = EditContent.Text;

            if (_note.Folder != null)
                _note.Folder.Notes.Remove(_note);

            if (EditFolderPicker.SelectedItem is FolderModel f && f.FolderName != "Без папки")
            {
                f.Notes.Add(_note);
                _note.Folder = f;
            }
            else _note.Folder = null;
        }

        RefreshMainPage();
        await CloseAsync();
    }

    private async void DeleteClicked(object? sender, EventArgs e)
    {
        bool delete = await Application.Current!.Windows[0].Page!.DisplayAlert(
            "Удалить", "Вы уверены?", "Удалить", "Отмена");
        if (!delete) return;

        if (_task != null)
        {
            _appState.TodayTasks.Remove(_task);
            _appState.PlannedTasks.Remove(_task);
            _appState.NotesTasks.Remove(_task);
            foreach (var f in _appState.Folders) f.Tasks.Remove(_task);
        }
        else if (_note != null)
        {
            _appState.Notes.Remove(_note);
            if (_note.Folder != null)
                _note.Folder.Notes.Remove(_note);
        }

        RefreshMainPage();
        await CloseAsync();
    }

    private void RefreshMainPage()
    {
        var mainPage = Application.Current?.Windows[0].Page;
        if (mainPage is NavTabbedPage nav)
        {
            foreach (var child in nav.Children)
            {
                if (child is MainPage mp)
                {
                    mp.RefreshTasksView();
                    break;
                }
            }
        }
    }
}