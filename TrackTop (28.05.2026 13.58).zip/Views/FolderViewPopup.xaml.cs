﻿using CommunityToolkit.Maui;
using CommunityToolkit.Maui.Extensions;
using CommunityToolkit.Maui.Views;

namespace TrackTop.Views;

public partial class FolderViewPopup : Popup
{
    private AppStateService _appState;

    public FolderViewPopup(FolderModel folder)
    {
        InitializeComponent();
        BindingContext = folder;
        _appState = Application.Current!.Handler!.MauiContext!.Services.GetService<AppStateService>()!;
    }

    private void OnTaskCheckTapped(object? sender, TappedEventArgs e)
    {
        if (sender is Border border && border.BindingContext is TaskModel task)
            task.IsCompleted = !task.IsCompleted;
    }

    private void OnExpandTapped(object? sender, TappedEventArgs e)
    {
        if (sender is Label label && label.BindingContext is TaskModel task)
            task.IsExpanded = !task.IsExpanded;
    }

    private async void OnDeleteTaskTapped(object? sender, TappedEventArgs e)
    {
        if (sender is Label label && label.BindingContext is TaskModel task)
        {
            bool delete = await Application.Current!.Windows[0].Page!.DisplayAlert(
                "Удалить задачу", "Вы уверены?", "Удалить", "Отмена");

            if (delete)
            {
                _appState.TodayTasks.Remove(task);
                _appState.PlannedTasks.Remove(task);
                _appState.NotesTasks.Remove(task);

                if (BindingContext is FolderModel folder)
                {
                    folder.Tasks.Remove(task);
                    folder.OnPropertyChanged(nameof(FolderModel.Tasks));
                    folder.OnPropertyChanged(nameof(FolderModel.TaskCount));
                }
            }
        }
    }

    private async void OnDeleteNoteTapped(object? sender, TappedEventArgs e)
    {
        if (sender is Label label && label.BindingContext is NoteModel note)
        {
            bool delete = await Application.Current!.Windows[0].Page!.DisplayAlert(
                "Удалить заметку", "Вы уверены?", "Удалить", "Отмена");

            if (delete)
            {
                _appState.Notes.Remove(note);
                if (BindingContext is FolderModel folder)
                {
                    folder.Notes.Remove(note);
                    folder.OnPropertyChanged(nameof(FolderModel.Notes));
                }
            }
        }
    }

    private void OnTitleTapped(object? sender, TappedEventArgs e)
    {
        if (sender is Label label && label.BindingContext is TaskModel task)
            OpenTaskEditor(task);
    }

    private void OnNoteTapped(object? sender, TappedEventArgs e)
    {
        if (sender is Label label && label.BindingContext is NoteModel note)
            OpenNoteEditor(note);
    }

    private async void OpenTaskEditor(TaskModel task)
    {
        await CloseAsync();

        var page = Application.Current?.Windows[0].Page;
        if (page != null)
        {
            await page.ShowPopupAsync(new TaskEditorPopup(task), new PopupOptions
            {
                CanBeDismissedByTappingOutsideOfPopup = false,
                PageOverlayColor = Color.FromRgba(0, 0, 0, 120)
            });
        }
    }

    private async void OpenNoteEditor(NoteModel note)
    {
        await CloseAsync();

        var page = Application.Current?.Windows[0].Page;
        if (page != null)
        {
            await page.ShowPopupAsync(new TaskEditorPopup(note), new PopupOptions
            {
                CanBeDismissedByTappingOutsideOfPopup = false,
                PageOverlayColor = Color.FromRgba(0, 0, 0, 120)
            });
        }
    }
}