﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommunityToolkit.Maui.Alerts;
using CommunityToolkit.Maui.Core;
using CommunityToolkit.Maui.Views;
namespace TrackTop.Views;
public partial class TaskCreator : Popup
{
    public TaskCreator()
    {
        InitializeComponent();
        TaskTimePicker.Time = null;
        TaskDatePicker.Date = null;
        var appState = Application.Current!.Handler!.MauiContext!.Services.GetService<AppStateService>();
        if (appState != null)
        {
            var folderList = new List<FolderModel>();
            folderList.Add(new FolderModel("#CCCCCC") { FolderName = "Без папки" });
            foreach (var folder in appState.Folders)
            {
                folderList.Add(folder);
            }
            FoldersPicker.ItemsSource = folderList;
            FoldersPicker.SelectedIndex = 0;
        }
    }
    
    private async void ClosePage(object? sender, EventArgs args)
    {
        await CloseAsync();
    }

    private async void CreateTask(object? sender, EventArgs args)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(TitleEntry.Text))
            {
                await ShowError("Нужно ввести название задачи!");
                return;
            }

            if (TaskDatePicker.Date is null)
            {
                await ShowError("Введите дату дедлайна задачи!");
                return;
            }

            string title = TitleEntry.Text;
            string description = TaskEditor.Text ?? "";
            DateOnly date = DateOnly.FromDateTime(((DateTime)TaskDatePicker.Date).Date);

            if (date < DateOnly.FromDateTime(DateTime.Now.Date))
            {
                await ShowError("Дата дедлайна не может быть в прошлом!");
                return;
            }

            TimeOnly? time = null;
            if (TaskTimePicker.Time is not null)
            {
                time = TimeOnly.FromTimeSpan((TimeSpan)TaskTimePicker.Time);
                if (time < TimeOnly.FromDateTime(DateTime.Now) && date == DateOnly.FromDateTime(DateTime.Now.Date))
                {
                    await ShowError("Время дедлайна не может быть в прошлом!");
                    return;
                }
            }

            bool isRegular = RegularSwitch.IsToggled;
            bool hasNotification = NotifySwitch.IsToggled;

            var task = new TaskModel(title, description, date, time, hasNotification);
            task.IsRegular = isRegular;
            task.HasNotification = hasNotification;

            var appState = Application.Current!.Handler!.MauiContext!.Services.GetService<AppStateService>()!;

            if (FoldersPicker.SelectedItem is FolderModel folder && folder.FolderName != "Без папки")
            {
                folder.Tasks.Add(task);
                task.Folder = folder;
                folder.OnPropertyChanged(nameof(FolderModel.TaskCount));
            }

            var today = DateOnly.FromDateTime(DateTime.Now.Date);

            if (date == today)
                appState.TodayTasks.Add(task);

            if (date >= today)
                appState.PlannedTasks.Add(task);

            if (hasNotification)
                appState.NotesTasks.Add(task);

            appState.SortAllTasks();

            if (Application.Current?.Windows[0].Page is NavTabbedPage nav)
            {
                foreach (var child in nav.Children)
                {
                    if (child is MainPage main)
                    {
                        main.RefreshTasksView();
                        break;
                    }
                }
            }

            await CloseAsync();
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"Ошибка при создании задачи: {ex.Message}");
        }
    }

    private async System.Threading.Tasks.Task ShowError(string message)
    {
        try
        {
            await Toast.Make(message, ToastDuration.Long, 15).Show();
        }
        catch
        {
            // Игнорируем — Toast может не работать на некоторых платформах
        }
    }
}