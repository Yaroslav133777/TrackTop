﻿using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace TrackTop;

public class TaskModel : INotifyPropertyChanged
{
    private string? _title;
    public string? Title
    {
        get => _title;
        set { _title = value; OnPropertyChanged(); }
    }

    private string? _description;
    public string? Description
    {
        get => _description;
        set { _description = value; OnPropertyChanged(); }
    }

    private DateOnly _date;
    public DateOnly Date
    {
        get => _date;
        set { _date = value; OnPropertyChanged(); }
    }

    private TimeOnly? _time;
    public TimeOnly? Time
    {
        get => _time;
        set { _time = value; OnPropertyChanged(); }
    }

    public bool Notify { get; set; }

    private bool _isCompleted;
    public bool IsCompleted
    {
        get => _isCompleted;
        set
        {
            _isCompleted = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(TextDecoration));
            OnPropertyChanged(nameof(Opacity));
        }
    }

    private bool _isExpanded;
    public bool IsExpanded
    {
        get => _isExpanded;
        set
        {
            _isExpanded = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(ExpandIcon));
        }
    }

    private bool _isRegular;
    public bool IsRegular
    {
        get => _isRegular;
        set
        {
            _isRegular = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(HasRegular));
        }
    }

    private bool _hasNotification;
    public bool HasNotification
    {
        get => _hasNotification;
        set
        {
            _hasNotification = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(NotificationIcon));
        }
    }

    public string? FolderName_Serialized { get; set; }
    public string? FolderColor_Serialized { get; set; }

    [JsonIgnore]
    public FolderModel? Folder { get; set; }

    [JsonIgnore]
    public string FolderName => Folder?.FolderName ?? "";

    [JsonIgnore]
    public bool HasFolder => Folder != null;

    [JsonIgnore]
    public TextDecorations TextDecoration => IsCompleted ? TextDecorations.Strikethrough : TextDecorations.None;

    [JsonIgnore]
    public double Opacity => IsCompleted ? 0.5 : 1.0;

    [JsonIgnore]
    public string ExpandIcon => IsExpanded ? "▲" : "▼";

    [JsonIgnore]
    public string NotificationIcon => HasNotification ? "🔔" : "🔕";

    [JsonIgnore]
    public bool HasRegular => IsRegular;

    public TaskModel() { }

    public TaskModel(string? title, string? description, DateOnly date, TimeOnly? time, bool notify)
    {
        _title = title;
        _description = description;
        _date = date;
        _time = time;
        _hasNotification = notify;
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    protected void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}