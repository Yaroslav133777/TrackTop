﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace TrackTop;

public class FolderModel : INotifyPropertyChanged
{
    private string _folderName = "default";
    public string FolderName
    {
        get => _folderName;
        set { _folderName = value; OnPropertyChanged(); }
    }

    public ObservableCollection<TaskModel> Tasks { get; set; } = new();
    public ObservableCollection<NoteModel> Notes { get; set; } = new();

    [JsonIgnore]
    public Color FolderColor { get; set; } = Colors.Gray;

    public string ColorHex
    {
        get => FolderColor.ToArgbHex();
        set => FolderColor = Color.FromArgb(value);
    }

    public int TaskCount => Tasks.Count;

    public FolderModel()
    {
        Tasks.CollectionChanged += (s, e) => OnPropertyChanged(nameof(TaskCount));
    }

    public FolderModel(string color)
    {
        ColorHex = color;
        Tasks.CollectionChanged += (s, e) => OnPropertyChanged(nameof(TaskCount));
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    public void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}